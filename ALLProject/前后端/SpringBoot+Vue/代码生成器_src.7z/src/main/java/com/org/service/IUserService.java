package com.org.service;

import com.org.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author congmu
 * @since 2023-08-02
 */
public interface IUserService extends IService<User> {

}
