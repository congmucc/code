<template>
  <div id="app">
    <School></School>
    <Student></Student>
  </div>
</template>

<script>

import School from './components/School.vue';
import Student from './components/Student.vue';

export default {
  // name是调试和开发工具通过name确定值，同时在动态组件和递归中也通过name属性进行识别
  name: "App",
  components: {
    School,
    Student
  },
};
</script>

<style>
</style>