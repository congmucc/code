<template>
  <div>
    <h2>
      <h2>学校姓名: {{ studentName }}</h2>
      <h2>学生年龄: {{ age }}</h2>
    </h2>
  </div>
</template>


<script>
export default {
  name: "MyStudent",
  data() {
    return {
      studentName: "张三",
      age: 18,
    };
  },
};
</script>

<style>
</style>