const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  // // 开启代理服务器(方式一)
  // devServer: {
  //   proxy: 'http://localhost:5000'
  // }
  // 开启代理服务器(方式二)
  devServer: {
    proxy: {
      '/api': { // 匹配所有以 '/api/' 开头的请求路径
        target: 'http://localhost:5000',  // 需要访问的服务器的 主机 协议和端口
        pathRewrite: {'^/api': ''}, // 将请求头改变成空字符串,防止出错
        ws: true, // 用于支持websocket
        changeOrigin: true // 用于控制请求头中的host值
      },
      '/foo': {
        target: 'http://localhost:5001',
        pathRewrite: {'^/foo': ''}, // 将请求头改变成空字符串,防止出错
        ws: true, // 用于支持websocket
        changeOrigin: true // 用于控制请求头中的host值
      }
    }
  }
})
