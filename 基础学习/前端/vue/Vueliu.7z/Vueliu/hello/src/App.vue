<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <!-- 3. 将vue主文件包含进来 -->
  <Hello></Hello>
</template>

<script>
// 1. 引用vue文件
import Hello from '../src/components/Hello.vue'

export default {
  name: 'App',
  components: {
    // 2. 进行注册
    Hello
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
