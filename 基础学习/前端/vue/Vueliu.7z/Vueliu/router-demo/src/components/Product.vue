<template>
    <div>
        <h3>商品</h3>
        <!-- 获取动态的id值 -->
        <p>{{ $route.params.id }}</p>
    </div>
</template>

<script>

export default {
    // 组件的名称
    name: 'Product'
}
</script>