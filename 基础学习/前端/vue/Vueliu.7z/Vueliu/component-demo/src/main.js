import Vue from 'vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue'

// 全局导入axios  this.$http 这个作为axios代替
import axios from 'axios';
// 配置请求根路径
axios.defaults.baseURL = "http://localhost8080"
// 将axios作为全局的自定义属性， 每个组件可以在内部直接访问(Vue2)
Vue.prototype.$http = axios
// 将axios作为全局的自定义属性， 每个组件可以在内部直接访问(Vue3)
// App.config.globalProperties.$http = axios


Vue.config.productionTip = false
// 全局注册，以便使用Vue.use(test)
Vue.use(ElementUI);

new Vue({
  render: h => h(App),
}).$mount('#app')
