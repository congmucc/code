<template>
     <el-table
    :data="tableData" 
    border
    style="width: 100%">
    <el-table-column
      fixed
      prop="id"
      label="编号"
      width="150">
    </el-table-column>
    <el-table-column
      prop="username"
      label="姓名"
      width="120">
    </el-table-column>
    <el-table-column
      prop="birthday"
      label="出生日期"
      width="120">
    </el-table-column>
    <el-table-column
      prop="city"
      label="市区"
      width="120">
    </el-table-column>
    <el-table-column
      prop="address"
      label="地址"
      width="300">
    </el-table-column>
    <el-table-column
      prop="zip"
      label="邮编"
      width="120">
    </el-table-column>
    <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>
        <el-button type="text" size="small">编辑</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
// import axios from 'axios';  单个的
  export default {
    methods: {
      handleClick(row) {
        console.log(row);
      }
    },
      // 因为这是Vue自带的函数，与data平级，所以不用放在methods中，只有自己创建的函数才能被放在methods中, 这是一个异步的过程，先打印App被挂载
      // created  作用：主键被创建的时候这个函数会被自动调用
    created:function() {
        console.log("App组件被创建了")
        // 回调函数里面的this会发生变化，这个箭头(箭头函数)是让this的作用域继承父级，即与created的this一样的
        // axios.get("http://localhost:8088/user/findAll").then(function(response){

        // axios.get("http://localhost:8088/user/findAll").then((response)=>{  这个是单个的导入axios， this.$http 是全局状态的axios
        this.$http.get("http://localhost:8088/user/findAll").then((response)=>{
            this.tableData = response.data
        console.log(response.data)
        })
    },
    data() {
      return {
        tableData:[]
      }
    }
  }
</script>