<template>
    <div>
        <h1>{{title}}</h1>
        <span>{{ rating }}</span>
        <button @click="fun">点击收藏</button>
    </div>
</template>


<script>

    // 导出， 这个export default 与外面的import相对应, {}里面可以加主键的属性
export default {
    name:"Move", // 一般来说用不上
    // 自定义的属性， 定义之后div里面就可以使用这个props里面定义的数据
    props:["title", "rating"],
    data:function() {
        return {
            
        }
    },
    created:function() {
        console.log("Movie组件被创建了")
    },
    methods: {
        fun() {
            alert("收藏成功")
        }
    }
}
</script>

<style>

</style>