<template>
  <div id="app">
    <!-- 加 : 进行数据绑定 -->
    <Movie v-for="movie in movies" :key="movie.id" :title="movie.title" :rating="movie.rating"></Movie>
    <Hello></Hello>
  </div>
</template>

<script>
import Movie from './components/Movie.vue';
import Hello from './components/Hello.vue';


export default {
  name: 'App',
  data:function() {
    return {
      // 数组
      movies:[
        {id:1, title:"金刚狼1",rating:8.7},
        {id:2, title:"金刚狼2",rating:8.8},
        {id:3, title:"金刚狼3",rating:8.9}
      ]
    }
  },

  // // 因为这是Vue自带的函数，与data平级，所以不用放在methods中，只有自己创建的函数才能被放在methods中, 这是一个异步的过程，先打印App被挂载
  // // created  作用：主键被创建的时候这个函数会被自动调用
  // created:function() {
  //   console.log("App组件被创建了")
  //   axios.get("http://localhost:8088/user/findAll").then(function(response){
  //     console.log(response.data)
  //   })
  // },

  mounted:function() {
    console.log("App被挂载(渲染到界面上)")
  },

  
  components: {
    Movie,
    Hello
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
