<template>
  <div class="hello">
    <!-- 这样写太麻烦了，可以看官方文档state中的computed用法 -->
    <!-- {{ this.$store.state.count }} -->

    <!-- 这个是computed，直接用count就行 -->
    {{ count }}
    <!-- 点击count+1 -->
    <button @click="add">+1</button>
    <ul>
      <li v-for="todo in doneTodos" :key="todo.id">{{ todo.text }}</li>
    </ul>

    {{ doneTodosCount }}

  </div>
</template>

<script>
// 在单独构建的版本中辅助函数为 Vuex.mapState
import { mapState, mapGetters } from 'vuex'

export default {
  name: 'HelloWorld',
  // 下面这三个方法访问都可以通过{{ count }}来接收

  // computed: {
  //   count () {
  //     return this.$store.state.count
  //   }
  // },

  // // mapState写法
  // computed:mapState ({
  //     // 下面三个写法一致 

  //     // // 箭头函数可使代码更简练
  //     // count: state => state.count,

  //     // // 传字符串参数 'count' 等同于 `state => state.count`
  //     // countAlias: 'count',

  //     // // 为了能够使用 `this` 获取局部状态，必须使用常规函数
  //     // countPlusLocalState (state) {
  //     //   return state.count + this.localCount
  //     // }
  // }),
  // // 当映射的计算属性的名称与 state 的子节点名称相同时，我们也可以给 mapState 传一个字符串数组
  // computed: mapState([
  //     // 映射 this.count 为 store.state.count
  //     'count', 'todos'
  // ]),


  // 导入多个map辅助函数
  computed: {
  // 使用对象展开运算符将 getter 混入 computed 对象中
  // 这三个点是函数展开
    ...mapGetters([
      'doneTodos'
    ]),
    // 增加其他的map辅助函数也是展开
    ...mapState([
    'count', 'todos'
    ])
  },


  methods: {
    add() {
      // this.$store.state.count += 1  // 这样也可以，但是不符合理念
      this.$store.commit("increment", 2) // 用到store中的increment这样才符合理念
    }
  }

}
</script>


<style scoped>

</style>
