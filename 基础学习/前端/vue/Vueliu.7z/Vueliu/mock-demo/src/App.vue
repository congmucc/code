<template>
  <div id="app">
    <img alt="Vue logo" :src="img">
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'App',
  data:function(){
    return {
      img:""
    }
  },
  // 被渲染的时候加载
  mounted:function(){
    axios.get('/product/search').then(res => {
      // 这里面有两层data，  因为res中也有一个data，存储返回的数据，
      //mock.js发送的data是在res.data中
      console.log(res.data.data.img)
      this.img = res.data.data.img
    })
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
